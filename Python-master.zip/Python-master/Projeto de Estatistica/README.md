# Projeto-Estat-stica
Projeto de estatística do período 2018.2
